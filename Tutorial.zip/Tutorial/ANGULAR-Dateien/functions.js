var $ = jQuery;

$(document).ready(
   function() {
     $('#popup-kiosk-container').show('slow', 
            function() {	     
               $('#popup-kiosk-container').fadeIn('slow');                        
      }
      );	  
	   $('#close').click(     
              function() {
                $('#popup-kiosk-container').fadeOut('slow');
              }
           );

});

var firstTimeChecker = 0;
$(document).ready(function() {
		/* Disable the country selection is no "ausland" product in tehe checkout */
		if ($('body.woocommerce-checkout').length > 0){
				var textContent = "";
				$('.variation-Abonnement-Typ').each(function() {
				    var currentElement = $(this);
				    textContent += currentElement.text();
				});
				if(textContent != ''){
				            //detect the "Ausland" text
				            if (/Ausland/i.test(textContent)){
				            }else{	            	
				            	$('<div id="err-abo-selection" style="display:none;"><p class="form-row form-row-wide">Land <abbr class="required" title="erforderlich">*</abbr><br /><input type="text" value="Deutschland" style="color:#474747;"  disabled="disabled" /><br /><span style="color:#666;font-size:11px!important;">Das von Ihnen gew&auml;hlte Abonnement kann nur innerhalb Deutschlands erworben werden. <a href="/cart">Aus dem Warenkorb entfernen</a></span></p></div>').insertAfter( "#billing_country_field" );	
						if(firstTimeChecker == 0){
							firstTimeChecker += 1;
				            		$("select#billing_country").select2().select2("val", 'DE');
				                	//$('select#billing_country').select2().enable(false);
				            		$('select#billing_country').change(function() {
				            			var selectedbillingcountry = $(this).find(":selected").val();
				            					if (selectedbillingcountry != 'DE')
				            					{
				            						$('#err-abo-selection').css("display","block");
				            	            		$( "#billing_country_field" ).hide();
				            					}
				            					else 
				            					{
				            						$('#err-abo-selection').css("display","none");
				            					}
				            		});
				   
								}
						//console.log(firstTimeChecker);
					}
				}
		}
});

//$(document).ready(
//	function(){
//		$("#my-registration-form").validate({
//			rules: {     
//				user_email: {email:true,required: true},
//				user_login: {required: true}
//			},						
//			messages: {
//				user_email: "Geben Sie bitte eine gültige Email ein",
//				user_login: "Bitte geben Sie einen Username ein",				
//			}
//		});
//	});
	

$(document).ready(function() {
	$.each($('a[rel="popup"]'), function(key, value) {
		var $e  = $(value);
		var url = $e.attr('href');

		$e.on('click', function(e) {
			var win = window.open(url, 'Share the Post!', 'width=500,height=450,resizable=yes');
			win.focus();

			return false;
		});
	});

	$.each($('.num-shares'), function(key, value) {
		var element = $(value);

		var platformKey  = element.data('platform-key');
		var platformName = element.data('platform-name');
		var url          = element.data('url');
		var urlOld       = element.data('url-old');

		getShares(platformKey, url, urlOld, function(numShares) {
			if (numShares == 0) {
				element.html(platformName);
			} else {
				element.html(numShares);
			}
		});
	});

	var insertedSidebar = false;

	$('.navbar-toggle').on('click', function(e) {
		if (insertedSidebar === false) {
			var navigation = $('#menu-main-menu').clone();
			var topics     = $('.topics-list').clone();
			var sidebar    = $('<div id="mobilenav">');

			sidebar.append(navigation);
			sidebar.append(topics);
			$('body').append(sidebar);
			$('#mobilenav').animate({
				left: '0px'
			}, 250);
			
			insertedSidebar = true;
		} else {
			$('#mobilenav').animate({
				left: '-200px'
			}, 250, function() {
				$('#mobilenav').remove();
			});

			insertedSidebar = false;
		}
	});

	if ($(window).width() > 992) {
		initSticky();
	}

	$(window).resize(function() {
		if ($(window).width() > 992) {
			initSticky();
		}
	});

	/*$(window).scroll(function() {
		$('.sticky').each(function(index) {
			var $e = $(this);

			if ($(window).scrollTop() + $(window).height() < $e.data('sticky-max')) {
				if ($(window).scrollTop() + $(window).height() >= $e.data('sticky-min')) {
					$e.css({
						position: 'fixed',
						left: $e.offset().left + 'px',
						bottom: '0px'
					});
				} else {
					$e.css({
						position: 'static'
					});
				}
			}
		});
	});*/





   $('.tax-filter').click( function(event) {
 
        // Prevent default action - opening tag page
        if (event.preventDefault) {
            event.preventDefault();
        } else {
            event.returnValue = false;
        }
 
        // Get tag slug from title attirbute
        var selecetd_taxonomy = $(this).attr('title');
 
        // After user click on tag, fade out list of posts
        $('.tagged-posts').fadeOut();
 
        data = {
            action: 'filter_posts', // function to execute
            afp_nonce: afp_vars.afp_nonce, // wp_nonce
            taxonomy: selecetd_taxonomy, // selected tag
            };
 
        $.post( afp_vars.afp_ajax_url, data, function(response) {
 
            if( response ) {
                // Display posts on page
                $('.tagged-posts').html( response );
                // Restore div visibility
                $('.tagged-posts').fadeIn();
            };
        });
    });




function showPassword() {
    
    var key_attr = $('#key').attr('type');
    
    if(key_attr != 'text') {
        
        $('.checkbox').addClass('show');
        $('#key').attr('type', 'text');
        
    } else {
        
        $('.checkbox').removeClass('show');
        $('#key').attr('type', 'password');
        
    }
    
}

// change domelement on login box // maybe someone has better Idea

	div1 = $('#loginform .login-remember');
	div2 = $('#loginform .login-submit');

	tdiv1 = div1.clone();
	tdiv2 = div2.clone();

	if(!div2.is(':empty')){
		div1.replaceWith(tdiv2);
		div2.replaceWith(tdiv1);

		tdiv1.addClass("replaced");
	}
	$('.passwort-vergessen').appendTo('#loginform');
	

// Buy Kiosk Abo Forms // show and hide the forms with select-box
$('#mag-type-select-box').change(function() {
//console.log($('input[name=magazine-type]:checked', '#mag-type-selector-for-purchase-container').val());

var valueofselectionmagtype = $('#mag-type-select-box :selected').val();
//console.log($('#mag-type-select-box'));
//console.log(selectedMag);
//var valueofselectionmagtype = $('input[name=magazine-type]:checked', '#mag-type-selector-for-purchase-container').val();
//console.log(valueofselectionmagtype);
	//first make all invisble
	$('#order-form-btm, #order-form-ecm, #order-form-em, #order-form-jm, #order-form-mtm, #order-form-phpm, #order-form-spk, #order-form-wd').hide();
	$('#' + valueofselectionmagtype).show();
	 
	}
);


$('.tooltip-fragezeichen').click(function() {
        $('p.tooltip-fragezeichen-helptext').toggle(300);
});
$('.abocodeform').click(function() {
        $('p.tooltip-fragezeichen-helptext').hide(300);
});


//Kiosk "Meine Abos" Question mark: to show some infos

$('.direkt-bestellen-abo span').click(function() {
	
	$('#mag-type-select-box').val('none');
	
	$('#mag-type-select-box').show();
	$('.upgrade-sub-form').show();
	$('.wpcf7-response-output').hide();
	$('.magcf7form').hide();
	$('.jetzt-lesen-anchor-infobox').hide();
	
	
	$('div.kiosk-abo-kaufen-popup-win').toggle(300);
	$( ".close-cf7-output" ).live( "click", function() {
		$('div.kiosk-abo-kaufen-popup-win').hide();
		$('.wpcf7-response-output').hide();
		$('.show-with-select-box').show();
		
		});
	
        
});

/* open / close info box (yellow) */

$('.jetzt-lesen-anchor-button').click(function() {
        $('.jetzt-lesen-anchor-infobox').show(100);
		$('div.kiosk-abo-kaufen-popup-win').hide(100);
});

$('.jetzt-lesen-anchor-infobox .jetzt-lesen-infobox-close').click(function() {
        $('.jetzt-lesen-anchor-infobox').hide(100);
});

/* open / close info boxes */

$('.class-info-kiosk-faq').click(function() {
	$('#info-kiosk-contact-anchor').hide(30);
	$('#info-kiosk-apps-anchor').hide(30);
	$('#info-kiosk-faq-anchor').show(30);
	if ($('.kiosk-info-submenue-div').hasClass("hidden")) {
		$('.kiosk-info-submenue-div').removeClass("hidden");
	}else {
		$('.kiosk-info-submenue-div').addClass("hidden");
	}
});
$('#info-kiosk-faq-anchor .info-kiosk-faq-close').click(function() {
	$('#info-kiosk-faq-anchor').hide(300);
	$("html, body").animate({ scrollTop: 0 }, 100);
});

$('.class-info-kiosk-contact').click(function() {
	$('#info-kiosk-faq-anchor').hide(30);
	$('#info-kiosk-apps-anchor').hide(30);
	$('#info-kiosk-contact-anchor').show(30);
	if ($('.kiosk-info-submenue-div').hasClass("hidden")) {
		$('.kiosk-info-submenue-div').removeClass("hidden");
	}else {
		$('.kiosk-info-submenue-div').addClass("hidden");
	}
});
$('#info-kiosk-contact-anchor .info-kiosk-contact-close').click(function() {
	$('#info-kiosk-contact-anchor').hide(300);
	$("html, body").animate({ scrollTop: 0 }, 100);
});

$('.class-info-kiosk-apps').click(function() {
	$('#info-kiosk-faq-anchor').hide(30);
	$('#info-kiosk-contact-anchor').hide(30);
	$('#info-kiosk-apps-anchor').show(30);
	if ($('.kiosk-info-submenue-div').hasClass("hidden")) {
		$('.kiosk-info-submenue-div').removeClass("hidden");
	}else {
		$('.kiosk-info-submenue-div').addClass("hidden");
	}
});
$('#info-kiosk-apps-anchor .info-kiosk-apps-close').click(function() {
	$('#info-kiosk-apps-anchor').hide(300);
	$("html, body").animate({ scrollTop: 0 }, 100);
});



/* open / close search box (anonymous) */
$( ".annonymuse-fts-result-content" ).hide();
var anonymousGetUrlParameter = function anonymousGetUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

var ftsParameterAnonymous = anonymousGetUrlParameter('fts-term');

if ($( "body" ).hasClass( "logged-in" )){
	if (typeof ftsParameterAnonymous !== 'undefined'){
		// $('html, body').animate({ scrollTop: ($('.kiosk-new-stream-ul').offset().top)}, 1000);
	}
} else{
function scrollto(element){
     $('html, body').animate({ scrollTop: ($('.annonymuse-fts-result-box').offset().top)}, 1000);
};

	
	if (typeof ftsParameterAnonymous !== 'undefined'){
		scrollto();
		if(ftsParameterAnonymous){
			$( ".annonymuse-fts-result-content" ).show();
		} /*else{
			alert('Please fill the the search field!');
			//console.log('Please fill the field!');
		}*/
	}
}

$('.fts-result-close-icon').click(function() {
	$('div.annonymuse-fts-result-content').hide(100);
});

/* INFOS ABOUT APPS DOWNLOAD */

if (navigator.userAgent.match(/Android/i)) {
	$('body.page-template-kioskv2 #mobile-menu').before('<div id="entwickler-app-dialog-box"><div class="inner-block"><div class="close-x-button"><i class="fa fa-times close-dialog-box"></i></div><div class="logo-and-info-text"><div class="entwickler-app-logo"><img src="/wp-content/themes/entwicklerDE/images/kiosk-app-logo.jpeg" alt="Entwickler Kiosk" /></div><div class="info-about-app"><p><strong>entwickler.kiosk-App</strong><br />Installieren Sie noch heute unsere kostenlose App auf Ihrem Gerät.</p></div></div><div class="app-download-button"><a href="https://play.google.com/store/apps/details?id=com.sandsmedia.apps.android.entwicklerkiosk" target="_blank" class="button btn btn-primary">VIEW</a></div></div></div>');
	$('div.close-x-button').click(function() {
		$('div#entwickler-app-dialog-box').hide(100);
	});
}

if ((navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i)) && !window.MSStream) {
	$('body.page-template-kioskv2 #mobile-menu').before('<div id="entwickler-app-dialog-box"><div class="inner-block"><div class="close-x-button"><i class="fa fa-times close-dialog-box"></i></div><div class="logo-and-info-text"><div class="entwickler-app-logo"><img src="/wp-content/themes/entwicklerDE/images/kiosk-app-logo.jpeg" alt="Entwickler Kiosk" style="border-radius: 15px;"/></div><div class="info-about-app"><p><strong>entwickler.kiosk-App</strong><br />Installieren Sie noch heute unsere kostenlose App auf Ihrem Gerät.</p></div></div><div class="app-download-button"><a href="https://itunes.apple.com/de/app/entwickler-kiosk/id929560208" target="_blank" class="button btn btn-primary">VIEW</a></div></div></div>');
	$('div.close-x-button').click(function() {
		$('div#entwickler-app-dialog-box').hide(100);
	});
	
}


/*

$('.mobile-submit-new-filter-btn').click(function() {
	$('#header-kiosk-stream-filter-form').submit(100);
});
*/

/* close error messages on Meine Abos box */
$('.abo-sub-code-field .error, .abo-code-validation-errors').click(function() {
        $('.abo-sub-code-field .error, .abo-code-validation-errors').hide(100);
});


$('#my-registration-form label.emailerror').click(function() {
        $('#my-registration-form label.emailerror').hide(100);
});

$('#my-registration-form label.usererror').click(function() {
        $('#my-registration-form label.usererror').hide(100);
});

$('#my-registration-form label.aboerror').click(function() {
        $('#my-registration-form label.aboerror').hide(100);
});

$('#my-registration-form input#user_email').click(function() {
        $('#my-registration-form label.emailerror').hide(100);
});

$('#my-registration-form input#user_login').click(function() {
        $('#my-registration-form label.usererror').hide(100);
});

$('#my-registration-form input#abocode').click(function() {
        $('#my-registration-form label.aboerror').hide(100);
});

$('#my-registration-form input#user_email').click(function() {
        $('#my-registration-form #user_email-error').hide(100);
});

$('#my-registration-form #user_email-error').click(function() {
        $('#my-registration-form #user_email-error').hide(100);
});

$('#my-registration-form input#user_login').click(function() {
        $('#my-registration-form #user_login-error').hide(100);
});

$('#my-registration-form #user_login-error').click(function() {
        $('#my-registration-form #user_login-error').hide(100);
});

$('#my-registration-form .kiosk-password-field').click(function() {
        $('#my-registration-form label.passworderror').hide(100);
});


});

function initSticky() {
	$('.sticky').each(function(index) {
		var $e = $(this);

		$e.data('sticky-min', $e.offset().top + $(this).height());
		$e.data('sticky-max', $e.parent().offset().top + $(this).parent().height());
	});
}

function getShares(platform, url, urlOld, callback) {
	var getUrl = templateDirUrl + '/count.php?platform=' + platform + '&url=' + url + '&old=' + urlOld;

	$.get(getUrl, function(result) {
		if (typeof result.shares == 'undefined') {
			callback(false);
		} else {
			callback(result.shares);
		}
	});
	
	
}



$(window).scroll(function() {

    if ($(this).scrollTop()>0)
     {
        $('.cc_banner-wrapper').fadeOut();
     }
    else
     {
      $('.cc_banner-wrapper').fadeOut();
     }
 });
 
// Sidebar changes to fix the dfp banner js bug
$(function(){
var displayHeight = $( window ).height();
var sidebarBlockHeight = displayHeight - 60;
$('.sands-sidebar-posts').css({ height : sidebarBlockHeight + 'px'});
});


/*************
** JOB ALL JS  
*************/

$(document).ready(function() {

// add class active to radio buttons on sortinng
if($('#option1').is(':checked')) { 
	$('.filter-sorting label.radio-date').addClass(' active ');
};

if($('#option2').is(':checked')) { 
	$('.filter-sorting label.radio-distance').addClass(' active ');
};

/*$( ".filter-sorting label" ).click(function() {
  $( ".gmw-form-1" ).submit();
	console.log($('input[name=gmw-ordering]:checked').val());
});
*/
$('input[name=gmw-ordering]').change(function() {
	$( ".gmw-form-1" ).submit();
});


// Job Mobile Sidebar
 $('.side-filter-mobile-toggle').click(function() {
	$( ".page-template-jobLanding .side-filter" ).toggle();
	$( ".tax-jobs .side-filter" ).toggle();
});

// REMOVE ALL SELECT OF SELECTED CATEGORIES 
$('.reset-all-checked-cats').click(function() {
	$('#filter-categories-block').find('input[type=checkbox]:checked').removeAttr('checked');
	$( ".gmw-form-1" ).submit();
});

// SUBMITT THE FORM AFTER CHANGE THE DISTANCE / REMOVE 'Kilometer' FROM SELECT BOX
$(".side-filter .filter-sorting .gmw-distance-select-1 option:contains('Kilometer')").hide();
$('.gmw-distance-select-1').change(function() {
	$( ".gmw-form-1" ).submit(); Kilometer
});

// JOB CATEGORIES SELECT BOX TOGGLE
 $('.sands-dropdown-job-taetigkeitsfeld-button').click(function() {
	$( ".sands-dropdown-job-taetigkeitsfeld-list" ).toggle();
	$( ".sands-dropdown-job-karrierelevel-list" ).hide();
	$( ".sands-dropdown-job-beschaeftigung-list" ).hide();
}); 
$('.sands-dropdown-job-karrierelevel-button').click(function() {
	$( ".sands-dropdown-job-karrierelevel-list" ).toggle();
	$( ".sands-dropdown-job-taetigkeitsfeld-list" ).hide();
	$( ".sands-dropdown-job-beschaeftigung-list" ).hide();
});
$('.sands-dropdown-job-beschaeftigung-button').click(function() {
	$( ".sands-dropdown-job-beschaeftigung-list" ).toggle();
	$( ".sands-dropdown-job-taetigkeitsfeld-list" ).hide();
	$( ".sands-dropdown-job-karrierelevel-list" ).hide();
});
// JOB CATEGORIES SELECT BOX POPUP
 $('.sands-dropdown-job-taetigkeitsfeld-button-popup').click(function() {
	$( ".sands-dropdown-job-taetigkeitsfeld-list-popup" ).toggle();
	$( ".sands-dropdown-job-karrierelevel-list-popup" ).hide();
}); 
$('.sands-dropdown-job-karrierelevel-button-popup').click(function() {
	$( ".sands-dropdown-job-karrierelevel-list-popup" ).toggle();
	$( ".sands-dropdown-job-taetigkeitsfeld-list-popup" ).hide();
});


/* JOB LOGO ON CREATE JOB LISTING PAGES*/ 
 $( ".sands-job-logo-add-job-page" ).css( "display", "block" );

});

// HIDE JOB CATEGORIES SELECT BOXES IF USERS CLICK SOMEWHERE 
$(document).mouseup(function (e){
    var container = $( " .sands-dropdown-job-taetigkeitsfeld-list , .sands-dropdown-job-karrierelevel-list , .sands-dropdown-job-beschaeftigung-list " );
    var buttonContainer = $( " .sands-dropdown-job-taetigkeitsfeld-button , .sands-dropdown-job-karrierelevel-button, .sands-dropdown-job-beschaeftigung-button ");

    if ((!container.is(e.target) && container.has(e.target).length === 0) && (!buttonContainer.is(e.target) && buttonContainer.has(e.target).length === 0)){
        container.hide();
    }
});

/* NAVIGATION FIX POSITION */
$(document).ready(function() {
	var divNavExist = $('div#navbar');
	if(divNavExist.length > 0){
		num = $('div#navbar').offset().top;
		$(window).bind('scroll', function() {
			 if ($(window).scrollTop() > num) {
				 $('div#navbar').addClass('nav-fixed');
			 }
			 else {
				 // num = $('div#navbar').offset().top;
				 $('div#navbar').removeClass('nav-fixed');
			 }
		});
	}
});


$(document).ready(function() {

  var owlcover = $("#lp-mag-cover");
 
  owlcover.owlCarousel({
 
      //responsive 
      itemsDesktop : [2500,1], 
      itemsDesktopSmall : [1199,1], 
      itemsTablet : [766,2], 
      itemsMobile : [420,1], 
      
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      // singleItem:true,
      pagination:false,
      navigationText : false,
      autoPlay : false,
      stopOnHover : true,
      // lazyLoad : true,
	  // center:true,
	  autoWidth:true
 
  });
 
});
$(document).ready(function() {
 if ($(window).width() > 310) {

  var owllogo = $("#lp-mag-cat-logo");
 
  owllogo.owlCarousel({

      //responsive 
      itemsDesktop : [2500,5], 
      itemsDesktopSmall : [1199,4], 
      itemsTablet: [767,2], 
      itemsMobile : [420,1], 
      
      slideSpeed : 100,
      paginationSpeed : 400,
      // singleItem:true,
      pagination:false,
      navigation : false,
      navigationText : false,
      autoPlay : true,
      stopOnHover : true,
      lazyLoad : false,
      center:true,
      autoWidth:false,
 
  });
 }
 
 var owlIssueLp = $("#more-issue-slider-on-maglp");
 
  owlIssueLp.owlCarousel({
 
      slideSpeed : 100,
      paginationSpeed : 400,
      singleItem:true,
      pagination:false,
      navigation : false,
      navigationText : false,
      autoPlay : true,
      stopOnHover : true,
      lazyLoad : false,
      center:true,
      autoWidth:false,
 
  });
 
});

$(document).ready(function() {
	$( ".mobile-price-table-features-starter" ).hide();
	$( ".mobile-price-table-features-professional" ).hide();
	$( ".mobile-price-table-features-premium" ).hide();
	$('.pricing-table-header-starter').click(function() {
		if($( '.pricing-table-header-starter .fa' ).hasClass( 'fa-angle-double-right' )){
			$( '.pricing-table-header-starter .fa-angle-double-right' ).addClass( "fa-angle-double-down" ).removeClass( "fa-angle-double-right" );
		}else if($( '.pricing-table-header-starter .fa' ).hasClass( 'fa-angle-double-down' )){
			$( '.pricing-table-header-starter .fa-angle-double-down' ).addClass( "fa-angle-double-right" ).removeClass( "fa-angle-double-down" );
		}
		$( '.mobile-price-table-features-starter' ).toggle();
	});
	$('.pricing-table-header-professional').click(function() {
		if($( '.pricing-table-header-professional .fa' ).hasClass( 'fa-angle-double-right' )){
			$( '.pricing-table-header-professional .fa-angle-double-right' ).addClass( "fa-angle-double-down" ).removeClass( "fa-angle-double-right" );
		}else if($( '.pricing-table-header-professional .fa' ).hasClass( 'fa-angle-double-down' )){
			$( '.pricing-table-header-professional .fa-angle-double-down' ).addClass( "fa-angle-double-right" ).removeClass( "fa-angle-double-down" );
		}
		$( '.mobile-price-table-features-professional' ).toggle();
	});
	$('.pricing-table-header-premium').click(function() {
		if($( '.pricing-table-header-premium .fa' ).hasClass( 'fa-angle-double-right' )){
			$( '.pricing-table-header-premium .fa-angle-double-right' ).addClass( "fa-angle-double-down" ).removeClass( "fa-angle-double-right" );
		}else if($( '.pricing-table-header-premium .fa' ).hasClass( 'fa-angle-double-down' )){
			$( '.pricing-table-header-premium .fa-angle-double-down' ).addClass( "fa-angle-double-right" ).removeClass( "fa-angle-double-down" );
		}
		$( '.mobile-price-table-features-premium' ).toggle();
	});
});

// MAGAZINES SINGLE -> TOGGLE INFORMATION (LIKE EDITORIALS - INHALTE )
// $(document).ready(function() {
	// var selectorContent = $('#inhalt');
	// var h = selectorContent[0].scrollHeight;
	// $('#more').click(function(e) {
		// e.stopPropagation();
		// $('div').animate({
			// 'height': h
		// })
	// });

	// $(document).click(function() {
		// $('div').animate({
			// 'height': '50px'
		// })
	// })
	
// });
