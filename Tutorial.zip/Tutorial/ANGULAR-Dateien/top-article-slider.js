$(document).ready(function() {
 
  var owl = $("#featured-posts-wrapper");
 
  owl.owlCarousel({
 
      navigation : true, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      pagination:false,
      rewindSpeed: 10,
      navigation : true,
      navigationText : false,
      autoPlay : 6500,//false,//6000, // true or time
      stopOnHover : true,
      lazyLoad : false
 
  });
 
});