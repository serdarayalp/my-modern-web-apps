jQuery.noConflict();
jQuery(document)
		.ready(
				function($) {
					$(".ja-sands-dropdown-job-taetigkeitsfeld-wrapper :input").attr("required", true);
					$(".ja-sands-dropdown-job-taetigkeitsfeld-wrapper :input").attr("data-msg", "Bitte wählen Sie mindestens ein Tätigkeitsfeld.");
					

					$("#jobalertpopup_submit")
							.click(
									function() {
										
										$spinnerelememt = $('#addjoballertspinner');
										$spinnerelememt.removeClass("hidden");
										$spinnerelememt.show();
										
										$submitButton = $('#jobalertpopup_submit');
										$submitButton.prop('disabled', true);
										var $form = $('#jobalertpopupform');
										var jobalertanswererror = $('#jobalertanswererror');
										var jobalertanswersuccess = $('#jobalertanswersuccess');
										var jobAlertFormValidator = $form.validate();
										// console.log(jobAlertFormValidator);
										var isFormValid = $form.valid();
										if (!isFormValid) {
											jobalertanswererror.removeClass("hidden");
											jobalertanswererror.show( "slow");
											jobalertanswersuccess.hide();
											jobalertanswererror.html('');
											if (jobAlertFormValidator.errorList.length > 0) {
												jobalertanswererror.append('<ul>');
												for (i = 0; i < jobAlertFormValidator.errorList.length; i++) {
												    jobalertanswererror.append('<li>' + jobAlertFormValidator.errorList[i].message + '</li>');
												    
												} 
												jobalertanswererror.append('</ul>');
												
											} else {
												jobalertanswererror.html('Bitte füllen Sie das Formular aus.');
											}
											$spinnerelememt.hide();
											$submitButton.prop('disabled', false);
											return;
										}
										
										var formData = $form.serialize();
										
										jQuery
												.ajax({
													type : 'POST',
													url : ajaxjobalert.ajaxurl,
													data : {
														action : 'jobalertajax_ajaxhandler',
														data : formData
													},
													success : function(data,
															textStatus,
															XMLHttpRequest) {
														// console.log($(jobalertanswersuccess));
														// console.log(data);
														jobalertanswersuccess.removeClass("hidden");
														jobalertanswersuccess.show( "slow");
														jobalertanswererror.hide();
														jobalertanswersuccess.html('');
														jobalertanswersuccess.append(data);
//														jobalertanswersuccess.append(textStatus);
														$spinnerelememt.hide();
														$submitButton.prop('disabled', false);
														$submitButton.addClass("hidden");
														$("#jobalertpopupform").addClass("hidden");
														$('#jobalertpopup').on('hidden.bs.modal', function () {
															$submitButton.removeClass("hidden");
															$("#jobalertpopupform").removeClass("hidden");
															jobalertanswersuccess.addClass("hidden");
														})
													},
													error : function(
															MLHttpRequest,
															textStatus,
															errorThrown) {
														jobalertanswererror.removeClass("hidden");
														jobalertanswererror.show( "slow");
														jobalertanswersuccess.hide();
														jobalertanswererror.html('');
														jobalertanswererror.append(MLHttpRequest.responseText);
														$spinnerelememt.hide();
														$submitButton.prop('disabled', false);
													}
												});
									});
					
					/* Reset the Job Butler form */
					$('.side-job-butler a img').click(function(){
						$('#jobalertpopupform').trigger("reset");
					});
					
					
					/* Validate Job Butler and disable the submit button  */
				  if($('#jobalertpopupform').length){
					$('#jobalertpopupform').validate({
				        rules: {
				        	email: {
				                required: true,
				                email: true
				            }/*,
				            'tax_input[job-taetigkeitsfeld][]': {
				            	required: true,
				            	minlength: 1
				            }*/
				        }
				    });		
					$("#jobalertpopup #gmw-address-2").rules("add", {required:true});
					$('#jobalertpopup .modal-content input:after').hide();
					$('#jobalertpopup .modal-content button.btn').prop('disabled', 'disabled');
					$('#jobalertpopup .modal-content input').on('keyup blur', function () {
			        	$('#jobalertpopup .modal-content input').on('keyup blur change',function() {
			        	    if ($('.sands-dropdown-job-taetigkeitsfeld-list-popup li input:checked').length && $('#jobalertpopupform').valid()) {
			        		  $('#jobalertpopup .modal-content button.btn').prop('disabled', false);
			        	    }else{
				        		$('#jobalertpopup .modal-content button.btn').prop('disabled', 'disabled');
				        	}
			        	});
				    });
				  }
					
				});
