$(function(){
	checktheContactMail();
    if ($.cookie('query') != null) {
     var CookieValue = $.cookie('query');
     printValues(CookieValue);
     $('#bookmark-job-box').css("display","block");
     checktheBox();
    } 
     else 
     {
        $.cookie('query',"", {expires:7, path:'/'});
        
     }
});  

function storeValues() {
	if ($.cookie('query') != null) {  
        var title = $(document).find("title").text();
        var url   = window.location.href;
        var final = title +"|"+url;
        var oldCookieValue = $.cookie('query');
        if(alreadyInserted(oldCookieValue, url))        	
        { 
    		$("#error_existing_job").show().delay(5000).fadeOut(); 
    	}
        else
    	{ 
        	$("#error_existing_job").css("display","none");
            var newCookieValue = oldCookieValue + "|" + final;
            $.cookie('query',newCookieValue );
            printValues(newCookieValue);
            $('#bookmark-job-box').css("display","block");
    	}
		
	}
    else 
    {
       $.cookie('query',"", {expires:7, path:'/'});
    }
	


}

function alreadyInserted(CookieValue, url) {
		var array = CookieValue.split("|");
		var i = 1; 
		var result = false;
        while (i < array.length) {    	
        	if(array[i]==url)
        	{ 
        		result = true;
        	}
        	else
        	{ 
        		result = false;
        	}
        	i++;
        }
        return result;
}


function printValues(CookieValue) {
        var array = CookieValue.split("|");
        var i = 1; 
        var toprint_result="";
        var toprint_result='<div id="bookmark-job-box">';
        var job_class_name="";
        var job_class_name2="";
        var city = "";
        while (i < array.length) {
        	city = $( ".single-sponsor-title h2" ).text();
        	new_title = array[i].replace('entwickler.de','');
        	new_title = new_title + "(" + city + ")"; 
            job_class_name= array[i].replace(/\s/g,'').toLowerCase();
            job_class_name2="'"+array[i]+ "'";
            toprint_result = toprint_result + '<div class="bookmarked-job-title '+ job_class_name +'"><a href="'+ array[i+1] +'" target="_blank">' + new_title + '</a> <a onClick="removeValue('+job_class_name2+')"><i class="fa fa-trash-o  icon-bkmk" aria-hidden="true"></i></a></div>';
            i=i+2;
        }
        toprint_result = toprint_result + "</div>"
        $('.result').html($(toprint_result ));
}

function removeValue(valuetoRemove) {
        var CookieValue = $.cookie('query');
        var array = CookieValue.split("|");
        var i = 1; 
        var z = 1;
        var result="";
        while ($.inArray(valuetoRemove, array) != -1) {
                i=getIndexoftheValue(array,valuetoRemove);
                z = i+1;
                array.splice(z, 1);
                array.splice(i, 1);
        }
        result = array.join('|');
        $.cookie('query',result );
        printValues(result);
        checktheBox();
        
}

function getIndexoftheValue(array,valuetoRemove) {
    var i=1;
    while(array[i] != valuetoRemove)
    {
        i++;
    }
    return i;
}

function checktheBox() {
    if ($('#bookmark-job-box').is(':empty')){
   	 $('#bookmark-job-box').css("background","transparent");   	 
   	 $('#bookmark-job-box').css("border","1px solid transparent");
   	$('#bookmark-job-box').css("display","none");
   	}
}

function isEmail(email) {
	var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return regex.test(email);
}

function btnSendEmail() {
	var friendemail = $('#friendemail').val();
	if( !isEmail(friendemail)) 
	{ 
		$( "#emailcheck" ).text( "Die eingegebene E-Mail-Adresse ist ungültig." );
		$( "#emailcheck" ).addClass("errorMessage");
		$( "#emailcheck" ).fadeIn(300).delay(3200).fadeOut(300);
	}
	else
	{ 
		$( "#emailcheck" ).text( "" );  
		var body_line =  escape("\n");
		var body_space =  escape("\b");
	    var subject = 'Ihr weitergeleitetes Stellenangebot von entwickler.jobs';
	    var new_title = $(document).find("title").text().replace('- entwickler.de','');
	    var comp_name= $('#hidden-company-name-field').val() ;
	    var message="";
	    message += "Sehr geehrter entwickler.jobs Nutzer," + body_line + body_line ;
	    message += "die unten angeführte Stellenanzeige wurde über www.entwickler.de/jobs weitergeleitet." + body_line + body_line  ;
	    message += "Stellenangebot:	 " + body_space + encodeURIComponent(new_title) + body_line  ;
	    message += "Unternehmen: " + body_space + encodeURIComponent(comp_name) + body_line  ;
	    message += "Link: " + body_space + window.location.href + body_line + body_line  ;
	    message += "Viel Erfolg bei der Bewerbung" + body_line  ;
	    message += "Ihr entwickler.jobs Team";

	    var emailBody = window.location.href;
	    window.location = 'mailto:' + friendemail + '?subject=' + subject + '&body=' + message;
	    $('#send-ta-friend-box').css("display","none");
	}
}


function displayFriendBox() {
	$('#send-ta-friend-box').css("display","block");
}

function btnCloseSend(){
	$('#send-ta-friend-box').css("display","none");
}

function checktheContactMail() {
	if ($('div.contact-body a[href^="mailto:"]').length) {
	var link1 = $('div.contact-body a[href^="mailto:"]').attr('href');
	var link2 = $('a#generic-link-contact').attr('href');
	if ((link1=='mailto: ')&&(link2=='')){
	}
	else{
	    if ($('div.contact-body a[href^="mailto:"]').is(':empty')){
	    	$('.jetzt-bewerben').css("display","block");
	    	var value = $('#generic-link-contact').attr("href");
	    	$("#jetztlink").attr("href", value);
	   	}
	    else
	    {
	    	$('.email-bewerben').css("display","block");
	    	var value = $('div.contact-body a[href^="mailto:"]').attr("href").replace(/ /g,'');
	    	$("#emaillink").attr("href", value);
	    }
	}
	}
		
}

function btnEmailBewerben() {
	var value = $('div.contact-body a[href^="mailto:"]').attr("href");
	window.location = value;
}
